from tkinter import  *
import datetime

cdown_value = 60

def start_typing():
    global cdown_value
    global cdown_label
    cdown_label = Label(text=str(cdown_value))
    cdown_label.pack()

    text = Label(text="A one minute typing test is like a sprint. If you make a mistake it is probably best to just "
                      "ignore it and keep typing the paragraphs. Of course accuracy is important, but your speed and accuracy"
                      " will get better as long as you treat this as a learning exercise. Come back a few days in a row and you "
                      "will start to see progress.A one minute typing test is like a sprint. If you make a mistake it is probably"
                      " best to just ignore it and keep typing the paragraphs. Of course accuracy is important, but your speed and accuracy "
                      "will get better as long as you treat "
                      "this as a learning exercise. Come back a few days in a row and you will start to see progress.",wraplength=500, justify="left", padx=10, pady=10)
    text.pack()
    start_count_down = Button(text="Start Typing", command=update_countdown)
    start_count_down.pack()
    global input_txt
    input_txt = Text(height=100,width=100, wrap=WORD)
    input_txt.pack()


def update_countdown():
    global cdown_value
    if cdown_value > 0:
        cdown_value -= 1
        cdown_label.config(text=str(cdown_value))
        window.after(1000, update_countdown)
    else:
        cdown_label.config(text="Time's up!")
        content = input_txt.get("1.0", "end-1c")
        words = content.split()
        print("gfuty")
        word_count = len(words)
        cdown_label.config(text=f"Time's up.Your typing speed is {word_count} wpm...")

        print("gfuty")


window = Tk()
window.title("Typing-Speed-Test DesktopApp")
window.config(padx=300,pady=200, background="#f7f5dd")

#Button to start
button_start = Button(text="Start", command=start_typing)
button_start.pack()

window.mainloop()